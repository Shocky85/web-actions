package flex.graphics;

import java.util.HashMap;
import java.util.Map;

public class ImageSnapshot extends HashMap
{
    private static final long serialVersionUID = 7914317354403674061L;

    public ImageSnapshot()
    {
    }

    private Map properties;
    private String contentType;
    private byte[] data;
    private int height;
    private int width;

    /**
     * The content type for the image encoding format that was used to capture
     * this snapshot.
     */
    public String getContentType()
    {
        return contentType;
    }

    public void setContentType(String value)
    {
        contentType = value;
    }

    /**
     * The encoded data representing the image snapshot.
     */
    public byte[] getData()
    {
        return data;
    }

    public void setData(byte[] value)
    {
        data = value;
    }

    /**
     * The image height in pixels.
     */
    public int getHeight()
    {
        return height;
    }

    public void setHeight(int value)
    {
        height = value;
    }

    /**
     * Additionl properties of the image.
     */
    public Map getProperties()
    {
        return properties;
    }

    public void setProperties(Map value)
    {
        properties = value;
    }

    /**
     * The image width in pixels.
     */
    public int getWidth()
    {
        return width;
    }

    public void setWidth(int value)
    {
        width = value;
    }

}

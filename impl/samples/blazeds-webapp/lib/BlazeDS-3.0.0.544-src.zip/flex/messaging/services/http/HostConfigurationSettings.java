/*************************************************************************
 * 
 * ADOBE CONFIDENTIAL
 * __________________
 * 
 *  [2002] - [2007] Adobe Systems Incorporated 
 *  All Rights Reserved.
 * 
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated
 * and its suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */
package flex.messaging.services.http;

/**
 * Collects the properties needed to create an Apache Commons HTTPClient
 * HostConfiguration. Holds all of the variables needed to describe an HTTP
 * connection to a host: remote host, port and protocol, proxy host and port,
 * local address, and virtual host.
 *  
 * @author Peter Farland
 * @see org.apache.commons.httpclient.HostConfiguration
 */
public class HostConfigurationSettings
{
    public static final String HOST = "host";
    public static final String PORT = "port";
    public static final String PROTOCOL = "protocol";
    public static final String PROTOCOL_FACFORY = "protocol-factory";
    public static final String LOCAL_ADDRESS = "local-address";
    public static final String MAX_CONNECTIONS = "max-connections";
    public static final String PROXY = "proxy";
    public static final String VIRTUAL_HOST = "virtual-host";

    private String host;    
    private int port;
    private String protocol;
    private ProtocolFactory protocolFactory;
    private String localAddress;
    private int maximumConnections;
    private String proxyHost;
    private int proxyPort;
    private String virtualHost;

    /**
     * Creates a default <code>HostConfigurationSettings</code> instance.
     */
    public HostConfigurationSettings()
    {
        maximumConnections = HTTPConnectionManagerSettings.DEFAULT_MAX_CONNECTIONS_HOST;
    }

    public String getHost()
    {
        return host;
    }

    public void setHost(String host)
    {
        this.host = host;
    }

    public String getLocalAddress()
    {
        return localAddress;
    }

    public void setLocalAddress(String localAddress)
    {
        this.localAddress = localAddress;
    }

    public int getMaximumConnections()
    {
        return maximumConnections;
    }

    public void setMaximumConnections(int maximumConnections)
    {
        this.maximumConnections = maximumConnections;
    }

    public int getPort()
    {
        return port;
    }

    public void setPort(int port)
    {
        this.port = port;
    }

    public String getProtocol()
    {
        return protocol;
    }

    public void setProtocol(String protocol)
    {
        this.protocol = protocol;
    }

    public ProtocolFactory getProtocolFactory()
    {
        return protocolFactory;
    }

    public void setProtocolFactory(ProtocolFactory protocolFactory)
    {
        this.protocolFactory = protocolFactory;
    }

    public String getProxyHost()
    {
        return proxyHost;
    }

    public void setProxyHost(String proxyHost)
    {
        this.proxyHost = proxyHost;
    }

    public int getProxyPort()
    {
        return proxyPort;
    }

    public void setProxyPort(int proxyPort)
    {
        this.proxyPort = proxyPort;
    }

    public String getVirtualHost()
    {
        return virtualHost;
    }

    public void setVirtualHost(String virtualHost)
    {
        this.virtualHost = virtualHost;
    }
}
